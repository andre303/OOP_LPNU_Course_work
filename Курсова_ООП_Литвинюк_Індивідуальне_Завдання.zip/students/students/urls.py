"""students URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

import diplomaStudent.views
urlpatterns = [
    path("/", diplomaStudent.views.landing, name="landing"),
    path("", diplomaStudent.views.landing, name="landing"),
    path("edit/<int:student_id>", diplomaStudent.views.editFrom, name="edit"),
    path("addStudent", diplomaStudent.views.addStudent, name="addStudent"),
    path("editStudent/<int:student_id>", diplomaStudent.views.editStudent, name="editStudent"),
    path("delete/<int:student_id>", diplomaStudent.views.delete, name="deleteStudent"),
    path("report/<int:student_id>", diplomaStudent.views.report, name="report"),
    path("add", diplomaStudent.views.addFrom, name="add"),
    path('admin/', admin.site.urls),
]
