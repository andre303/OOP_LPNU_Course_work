from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import *
from .forms import *
def landing(request):
    students =  Student.objects.all()
    return render(request, "main.html", {"students":students })

def addFrom(request):
    form = StudentForm()
    return  render(request, "form.html", {"form":form })

def addStudent(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        student = form.save()
        student.save()
    return redirect('landing')

def editStudent(request, student_id):
    if request.method == "POST":
        item = get_object_or_404(Student, pk=student_id)
        form = StudentForm(request.POST, instance = item)
        form.save()
    return redirect('landing')

def editFrom(request, student_id):
    item = get_object_or_404(Student, pk=student_id)
    form = StudentForm(instance=item)
    return  render(request, "editForm.html", {"form":form, "studentId": student_id})

def delete(request, student_id):
    Student.objects.get(pk=student_id).delete()
    return redirect('landing')

def report(request, student_id):
    item = get_object_or_404(Student, pk = student_id)
    return  render(request, "diploma.html", {"student":item })