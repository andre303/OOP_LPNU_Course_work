from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
# Create your models here.

class Student(models.Model):
    student_name = models.CharField(
        blank=True, max_length=250, help_text=("Student name")
    )
    teacher_name = models.CharField(
        blank=True, max_length=250, help_text=("Teacher name")
    )
    theme_name = models.CharField(
        blank=True, max_length=250, help_text=("Name of the diploma project")
    )
    mark = models.IntegerField(
        default=1,
        validators=[MaxValueValidator(100), MinValueValidator(1)]
     )
    diplomaSubmissionDate = models.DateField(null=True,help_text=("Submission date"))
    def __str__(self):
        return self.student_name 