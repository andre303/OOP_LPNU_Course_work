from django import forms
from django.forms import fields,ModelForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit, Reset
from .models import *

class DateInput(forms.TimeInput):
    input_type = "date"

class StudentForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(StudentForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.add_input(Submit('submit', 'Додати', css_class='btn-primary'))
        self.helper.add_input(Reset('reset', 'Відмінити', css_class='btn-secondary'))
        for field in self.fields:
            self.fields[field].required = True
    class Meta:
        model = Student
        exclude = []
        widgets = {
            'diplomaSubmissionDate':DateInput()
        }
        labels = {
            'student_name': "Ім'я студента",
            'teacher_name':'Ім\'я викладача',
            'theme_name':'Тема дипломної роботи',
            'mark':'Оцінка',
            'diplomaSubmissionDate':'Дата захисту диплома',
        }
        help_texts = {
            'student_name': '',
            'teacher_name':'',
            'theme_name':'',
            'mark':'',
            'diplomaSubmissionDate':'',
        }